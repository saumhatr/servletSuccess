create sequence Booking_Id_Seq1 start with 1 increment by 1;
Select Booking_Id_Seq1.NEXTVAL from dual;
INSERT INTO bookingInformation VALUES (1,'sdsa',3,'business',3000,11,'a232','pune','delhi');
desc bookingInformation;
select * from bookingInformation;
DELETE FROM bookingInformation WHERE booking_id='ARS2';
select * from users;
insert into users values('airline-exec','1234','Pooja');
insert into users values('admin','admin','Deepak');

SELECT  booking_id, cust_email,no_of_passenger, class_type,  total_fare,seat_numbers, creditcard_info,  src_city,dest_city FROM bookingInformation WHERE booking_id='ARS3';

SELECT  booking_id, cust_email,no_of_passengers, class_type,  total_fare,seat_numbers, creditcard_info,  src_city,dest_city FROM bookingInformation WHERE booking_id='ARS3';



select * from FLIGHT_INFORMATION;

alter table bookingInformation add flightno references FLIGHT_INFORMATION(flightno);

alter table FLIGHT_INFORMATION add primary key(flightno);

select flightno from flight_information where dep_city='Mumbai' and arr_city='Guwahati';