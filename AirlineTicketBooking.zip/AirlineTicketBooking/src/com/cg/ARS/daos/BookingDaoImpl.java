package com.cg.ARS.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ARS.dto.Airport;
import com.cg.ARS.dto.BookingInformation;
import com.cg.ARS.dto.FlightInfo;
import com.cg.ARS.dto.UserClass;
import com.cg.ARS.exceptions.BookingExceptions;
import com.cg.ARS.util.JndiUtil;



public class BookingDaoImpl implements BookingDao {


	Connection conn;
	PreparedStatement stmt;
	private JndiUtil util;
	
	public BookingDaoImpl() throws BookingExceptions {
		util = new JndiUtil();
	}
	
	@Override
	public boolean validateAdmin(String userName) throws BookingExceptions {
		String query="SELECT PASSWORD FROM USERS WHERE USERNAME=?";
		ResultSet res;
		try {
			conn=util.getConnection();
			stmt=conn.prepareStatement(query);
			stmt.setString(1, "username");
			res=stmt.executeQuery();
			if(res.next()){
				return true;
			}
		} catch (SQLException e) {
			
			throw new BookingExceptions("UserName Does not exist");
		}
		
		return false;
	}

	@Override
	public List<FlightInfo> showAll() throws BookingExceptions{
		
		String query="select flightno,airline,dep_city,arr_city,dep_date,arr_date,dep_time,arr_time,firstseats,firstseatfare,bussseats,BussSeatsFare from flight_information";

		List<FlightInfo> flightlistshow;
		
		try {
			flightlistshow =new ArrayList<FlightInfo>();
			conn=util.getConnection();
			stmt=conn.prepareStatement(query);
			ResultSet res=stmt.executeQuery();
			
			System.out.println("ResultSet res"+res.toString());
				while(res.next())
				{
					
					FlightInfo flight=new FlightInfo();
					System.out.println("flightno"+res.getString("flightno"));
					String fno=res.getString("flightno");
					flight.setFlightno(fno);
					String aname=res.getString("airline");
					flight.setAirlinename(aname);
					flight.setDept_city(res.getString("dep_city"));
					flight.setArr_city(res.getString("arr_city"));
					flight.setDep_date(res.getDate("dep_date"));
					flight.setArr_date(res.getDate("arr_date"));
					flight.setDep_time(res.getString("dep_time"));
					flight.setArr_time(res.getString("arr_time"));
					flight.setFirstseats(res.getInt("firstseats"));
					flight.setFirstseatfare(res.getInt("firstseatfare"));
					flight.setBussseats(res.getInt("bussseats"));
					flight.setBussseatfare(res.getInt("BussSeatsFare"));
					System.out.println(flight.toString());
					flightlistshow.add(flight);
				}
					
		 } catch (SQLException e) {
			
			return null;
			
		}

		return flightlistshow;
	}

	private int getBookingId() {
		int bookingId = 0;
	 
			
			try {
				conn=util.getConnection();
				String query="Select Booking_Id_Seq1.NEXTVAL from dual";
				stmt=conn.prepareStatement(query);
				ResultSet rs=stmt.executeQuery();
				while(rs.next())
				{	
					bookingId=rs.getInt(1);
				}
				
				//mylogger.info("Booking ID generated"+bookingId);

			} catch (SQLException e) {
				//mylogger.error("Booking ID not generated ");
				System.out.println("SQLException while generating BookingID");
				//e.printStackTrace();
			}
		   
		return bookingId;
	}
	
	public boolean addBookingDetails(BookingInformation book)throws BookingExceptions{
		
		int bookid=getBookingId();
		String id=""+bookid;
		String bid="ARS".concat(id);
		
	    int rec;
		String query="INSERT INTO bookingInformation VALUES (?,?,?,?,?,?,?,?,?,?)";
		try {
			conn=util.getConnection();
			stmt=conn.prepareStatement(query);
			stmt.setString(1,bid);
			stmt.setString(2,book.getCust_email());
			stmt.setInt(3,book.getNo_of_passenger());
			stmt.setString(4,book.getClass_type());
			stmt.setInt(5,book.getTotal_fare());
			stmt.setInt(6,book.getSeat_number());
			stmt.setString(7,book.getCreditcard_info());
			stmt.setString(8,book.getSrc_city());
			stmt.setString(9,book.getDest_city());
			stmt.setString(10, book.getFlightno());
			rec=stmt.executeUpdate();
			
			if(rec!=0)
			{
				System.out.println("Data Inserted in booking table");
				//mylogger.info("Data Inserted in purchase table with purchaseid "+pid);
				return true;	
			}
			
		} catch (SQLException e) {
				//e.printStackTrace();
			//mylogger.error("Data not updated in purchase table");
			throw new BookingExceptions("Data not Inserted in booking table"); 
		}
		
		return false;
	}
		

	public boolean cancelBooking(String bookid) throws BookingExceptions {
		
		String query="DELETE FROM bookingInformation WHERE booking_id=?";
		int rec=0;
		
		try {
			conn=util.getConnection();
			stmt=conn.prepareStatement(query);
			stmt.setString(1, bookid);
			rec=stmt.executeUpdate();
			if(rec>0)
				{
				System.out.println("Data deleted with booking id"+bookid);
			   // mylogger.info("Data deleted with mobile id"+bookid);
				return true;
				}
			else
				System.out.println("Invalid booking Id");
			
		} catch (SQLException e) {
			//mylogger.error(" Data Not found with id "+mobileid);
			System.out.println("Invalid booking Id");
			throw new BookingExceptions("Data not deleted"); 
			
		}
		finally
		{
		   try {
				stmt.close();
				conn.close();
			  } catch (SQLException e) {
				e.printStackTrace();	
			}
		}
		
		
		return false;
	}

	@Override
	public UserClass getUserDetails(String userName) throws BookingExceptions {
		
		ResultSet rs=null;
		String qry="SELECT password,userfname from users where username=?";
		try {
			
			conn =util.getConnection();
			stmt=conn.prepareStatement(qry);
			stmt.setString(1,userName);
			
			rs=stmt.executeQuery();
			if(rs.next())             //username  min one record should be there
			{
			
				String password=rs.getString("password");
				String fullName=rs.getString("userfname");
				
				UserClass user=new UserClass(userName,password);
				return user;
			}
			else
			{
				throw new BookingExceptions("UserName wrong");
			}
			
		} catch (SQLException e) {
			throw new BookingExceptions("JDBC Failed",e);      //exception chaining
			
		}
		finally
		{
			try {
				if(rs!=null)
				{	
				   rs.close();
				}
				if(stmt!=null)
				{
				 stmt.close();
					
				}
				if(conn!=null)
				{
					conn.close();
				}
			} catch (SQLException e) {
				
				throw new BookingExceptions("JDBC connection closing Failed");
			}
		}
		
	}
	

	@Override
	public BookingInformation showBookingDetails(String bookId) throws BookingExceptions {
		
			BookingInformation bookingDet=new BookingInformation();
		
		String query="SELECT  booking_id, cust_email,no_of_passengers, class_type,  total_fare,seat_numbers, creditcard_info,  src_city,dest_city,flightno FROM bookingInformation WHERE booking_id=?";
		try {
			conn =util.getConnection();
			stmt=conn.prepareStatement(query);
			stmt.setString(1,bookId);
			ResultSet res=stmt.executeQuery();
			while(res.next()){
				bookingDet.setBooking_id(bookId);
				bookingDet.setCust_email(res.getString("cust_email"));
				bookingDet.setNo_of_passenger(res.getInt("no_of_passengers"));
				bookingDet.setClass_type(res.getString("class_type"));
				bookingDet.setTotal_fare(res.getInt("total_fare"));
				bookingDet.setSeat_number(res.getInt("seat_numbers"));
				bookingDet.setCreditcard_info(res.getString("creditcard_info"));
				bookingDet.setSrc_city(res.getString("src_city"));
				bookingDet.setDest_city(res.getString("dest_city"));
				bookingDet.setFlightno(res.getString("flightno"));
				
			}
		} catch ( SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BookingExceptions("Data Not found");
		}finally{
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return bookingDet;
	}


	@Override
 	public boolean updateFlightSeatQuantity(String flightno, int noofpassengers,String seattype) throws BookingExceptions {
 		
 		String query = null;
		if(seattype.equals("Business"))
		{
 		   query="UPDATE flight_information set bussseats=bussseats-? where flightno=? ";
		}
		else if(seattype.equals("First"))
		{
		  query="UPDATE flight_information set firstseats=firstseats-? where flightno=? ";
		}

 		int rec=0;
 		try {
 			conn =util.getConnection();
 			stmt=conn.prepareStatement(query);
 			stmt.setInt(1,noofpassengers);
 			stmt.setString(2,flightno);	
 			rec=stmt.executeUpdate();
 			
 			if(rec>0)
 				{
 				 System.out.println("flight seats table updated");
 				 return true;
 				}
 			
 		} catch (SQLException e) {
 			System.out.println(e);
 				
 			throw new BookingExceptions("Data not updated in Flight table"+e.getMessage()); 
 		}
 		
 		return false;
 	}
	
	
	public String getFlightNo(String src,String dest) throws BookingExceptions
	{
		String query="select flightno from flight_information where dep_city=? and arr_city=? ";
		ResultSet res;
		String flightNo = null;
			try {
				conn =util.getConnection();
				stmt=conn.prepareStatement(query);
				stmt.setString(1, src);
				stmt.setString(2, dest);
				res=stmt.executeQuery();
				if(res.next())
					{
					 flightNo=res.getString("flightno");
					 System.out.println("flightNo"+flightNo);
					}
				return flightNo;
			} catch (SQLException e) {
				throw new BookingExceptions("No flight available with given source and destination"+e.getMessage()); 
			}
		
	}

	@Override
	public boolean updateFlightInfo(FlightInfo info) throws BookingExceptions {
		//	String query = "UPDATE FLIGHTINFO SET dept_city=?, arr_city=?,dep_date=?,arr_date=?,dep_time=?,arr_time=?,firstseats=?,"
		return false;
	}

	@Override
	public boolean deleteFlight(String no) throws BookingExceptions {
		
		String query="DELETE FROM FLIGHT_INFORMATION WHERE flightno=?";
		int rec=0;
		
		try {
			conn=util.getConnection();
			stmt=conn.prepareStatement(query);
			stmt.setString(1, no);
			rec=stmt.executeUpdate();
			if(rec>0)
				{
				System.out.println("Data deleted with Flight no"+no);
				return true;
				}
			else
				System.out.println("Invalid Flight No");
			
		} catch (SQLException e) {
			
			System.out.println("Invalid Flight No");
			throw new BookingExceptions("Data not deleted"); 
			
		}
		finally
		{
		   try {
			 
				stmt.close();
				conn.close();
				
			  } catch (SQLException e) {
				e.printStackTrace();	
			}
	}
		return false;
	}

	@Override
	public boolean insertFlightDetails(FlightInfo flight)
			throws BookingExceptions {
		
		
	    int rec=0;
		String query="INSERT INTO FLIGHT_INFORMATION VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			conn=util.getConnection();
			stmt=conn.prepareStatement(query);
		
			stmt.setString(1,flight.getFlightno());
			stmt.setString(2,flight.getAirlinename());
			stmt.setString(3,flight.getDept_city());
			stmt.setString(4,flight.getArr_city());
			stmt.setDate(5,flight.getDep_date());
			stmt.setDate(6,flight.getArr_date());
			stmt.setString(7,flight.getDep_time());
			stmt.setString(8,flight.getArr_time());
			stmt.setInt(9, flight.getFirstseats());
			stmt.setInt(10, flight.getFirstseatfare());
			stmt.setInt(11, flight.getBussseats());
			stmt.setInt(12,flight.getBussseatfare());
			rec=stmt.executeUpdate();
			
			if(rec!=0)
			{
				System.out.println("Data Inserted in flight table");
				//mylogger.info("Data Inserted in purchase table with purchaseid "+pid);
				return true;
			
			}
			
		} catch (SQLException e) {
				//e.printStackTrace();
			//mylogger.error("Data not updated in purchase table");
			throw new BookingExceptions("Data not Inserted in flight table"); 
		}
		
		return false;
	}


}


