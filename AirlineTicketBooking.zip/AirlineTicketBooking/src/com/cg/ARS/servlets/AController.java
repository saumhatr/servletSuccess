package com.cg.ARS.servlets;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ARS.dto.FlightInfo;
import com.cg.ARS.exceptions.BookingExceptions;
import com.cg.ARS.services.BookingServices;
import com.cg.ARS.services.BookingServicesImpl;

@WebServlet("*.do")
public class AController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BookingServices services;
	
	public AController() throws BookingExceptions {
		services = new BookingServicesImpl();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cmd = request.getServletPath();
		System.out.println(cmd);
		String nextJsp = null;
		RequestDispatcher dispatcher = null;
		
		switch (cmd) {
		
		case "/home.do":
			nextJsp="home.jsp";
			break;
		
		
		case "/admin.do":
				nextJsp="admin.jsp";
				break;
			
		case "/adminLogin.do":
			String userName = request.getParameter("userNm");
			String password = request.getParameter("password");
			try {
				boolean result=services.validateAdmin(userName);
				nextJsp="adminHome.jsp";
			} catch (BookingExceptions e) {
				System.out.println("Wrong Credentials");
			}
			
			/*if(username.equalsIgnoreCase("admin") && password.equalsIgnoreCase("admin")){
				nextJsp="adminHome.jsp";
			}*/
			break;
			
		case "/adminUpdate.do":
			nextJsp="adminUpdate.jsp";
			break;
			
		case "/flightInfo.do":
			List<FlightInfo> fList = null;
			try {
				fList = services.showAll();
			} catch (BookingExceptions e) {
				System.out.println("Data not found.");
			}
			request.setAttribute("fList", fList);
			nextJsp="flightInfo.jsp";
			break;
			
		case "/addFlight.do":
			nextJsp="addFlight.jsp";
	
			break;
		
		case "/successInsert.do":
		FlightInfo info = new FlightInfo();
			info.setFlightno(request.getParameter("flightNo"));
			info.setAirlinename(request.getParameter("airLine"));
			info.setDept_city(request.getParameter("src"));
			info.setArr_city(request.getParameter("dest"));
			
			try {
				String d=request.getParameter("dDate").toString();
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date date = sdf1.parse(d);
				java.sql.Date sqldeptDate = new Date(date.getTime());
				System.out.println(sqldeptDate);
				info.setDep_date(sqldeptDate);
				
				String a=request.getParameter("aDate").toString();
				SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date date1 = sdf2.parse(d);
				java.sql.Date sqlarrDate = new Date(date.getTime());
				System.out.println(sqlarrDate);
				info.setArr_date(sqlarrDate);
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			info.setDep_time(request.getParameter("dTime"));
			info.setArr_time(request.getParameter("aTime"));
			
			String fseat=request.getParameter("fSeats");
			info.setFirstseats(Integer.parseInt(fseat));
			
			String fSeatFare=request.getParameter("fSeatsFare");
			info.setFirstseatfare(Integer.parseInt(fSeatFare));
			
			String bseat=request.getParameter("bSeats");
			info.setBussseats(Integer.parseInt(bseat));
			
			String bSeatfare=request.getParameter("bSeatsFare");
			info.setBussseatfare(Integer.parseInt(bSeatfare));
			
			try {
				services.insertFlightDetails(info);
				nextJsp = "successInsert.jsp";
			} catch (BookingExceptions e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
			
		case "/updateFlightDetails.do":
			String idjsp = request.getParameter("id");
			String id=idjsp.substring(3);
			request.setAttribute("flightNo", id);
			String airLine = request.getParameter("name");
			request.setAttribute("airline", airLine);
			System.out.println(id);
			nextJsp = "updateFlightDetails.jsp";
			break;
			
			
		case "/deleteFlights.do":
			String no1 = request.getParameter("id");
			System.out.println(no1);
			//String no=no1.substring(3);
			//System.out.println(no);
			try {
				
				boolean status=	services.deleteFlight(no1);
				System.out.println(status);
				if(status==true){
				nextJsp = "successDelete.jsp";
				}
			} catch (BookingExceptions e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			
			break;
			
		case "/executive.do":
			
			nextJsp = "executive.jsp";
			break;
			
		case "/user.do":
			nextJsp = "user.jsp";
			break;
			
			
		default:
			break;
		}
			
		dispatcher = request.getRequestDispatcher(nextJsp);
		dispatcher.forward(request, response);
	}

}
