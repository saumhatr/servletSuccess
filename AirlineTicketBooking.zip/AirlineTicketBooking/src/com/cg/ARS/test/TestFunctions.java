package com.cg.ARS.test;

import java.util.List;
import java.util.Scanner;

import com.cg.ARS.dto.BookingInformation;
import com.cg.ARS.dto.FlightInfo;
import com.cg.ARS.exceptions.BookingExceptions;
import com.cg.ARS.services.BookingServices;
import com.cg.ARS.services.BookingServicesImpl;

public class TestFunctions {

	public static void main(String[] args) {
		
		Menu();	
	}

	public static void Menu()
	{
		System.out.println("Airline Ticket Booking Menu:");
		System.out.println("1.Check Authentic User");
		System.out.println("2.Show Flight Details");
		System.out.println("3.Book Flight");
		System.out.println("4.Cancel(delete) Booking");
		System.out.println("5.Show Booking Details on userid");
		System.out.println("6.Exit");
		System.out.println("Enter your choice");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		SwitchMenuChoice(choice);
		
	}
	
	public static void SwitchMenuChoice(int choice)
	{
		BookingServices service=new BookingServicesImpl();
		BookingInformation b=new BookingInformation();
		List<FlightInfo> info;
		
		switch(choice)
		{
		case 1:
			
			boolean user;
			try {
				System.out.println("Enter userID");  //Insert Booking Details
				Scanner sc=new Scanner(System.in);
				String userid=sc.next();
				System.out.println("Enter password"); 
				String password=sc.next();
				user = service.isUserAuthenticated(userid, password);
				System.out.println("Authentic user"+user);
			} catch (BookingExceptions e) {
				
				e.printStackTrace();
			}
			
			break;
		
		case 2:
			try {
				info = service.showAll();  //Show Flight Information
			} catch (BookingExceptions e) {
				
				e.printStackTrace();
			}        
			break;
		
		case 3:
			System.out.println("Enter email");  //Insert Booking Details
			Scanner sc=new Scanner(System.in);
			String email=sc.nextLine();
			b.setCust_email(email);
			System.out.println("Enter no of passengers");
			int nop=sc.nextInt();
			b.setNo_of_passenger(nop);
			
			System.out.println("Enter classType(Business or First)");
			String class1=sc.next();
			b.setClass_type(class1);
			
			System.out.println("Enter credit card info");
			String creditcard=sc.next();
			b.setCreditcard_info(creditcard);
			
			b.setTotal_fare(nop*1000);
			System.out.println("Enter source city");
			String src=sc.next();
			b.setSrc_city(src);
			
			System.out.println("Enter dest city");
			String dest=sc.next();
			b.setDest_city(dest);
			
			/*System.out.println("Enter flightno");
			String flightno1=sc.next();
			b.setFlightno(flightno1);*/
			
			
			
			boolean updateInsert,updateFlight;
			try {
				String flightno1=service.getFlightNo(src,dest);
				b.setFlightno(flightno1);
				System.out.println("flightno1"+flightno1);
				
				if(flightno1 !=null)
				{	
				updateInsert = service.addBookingDetails(b);
				updateFlight=service.updateFlightSeatQuantity(flightno1, nop, class1);
				System.out.println("Inserted"+updateInsert);
				System.out.println("Updated flight info"+updateFlight);
				}
				else
				{
					System.out.println("No flight available for this route");
				}
			} catch (BookingExceptions e) {
				
				e.printStackTrace();
			}
			
			break;
			
		case 4:
			boolean cancel;
			try {
				System.out.println("Enter BookingID to be deleted");  
				Scanner sc1=new Scanner(System.in);
				String bookid=sc1.next();
				cancel = service.cancelBooking(bookid); //Cancel Booked Ticket
				System.out.println("canceled"+cancel);
			} catch (BookingExceptions e) {
				
				e.printStackTrace();
			} 
			
			break;
		
		case 5:
			
			BookingInformation book;
			try {
				System.out.println("Enter BookingID for details to be shown");  
				Scanner sc1=new Scanner(System.in);
				String bookid=sc1.next();
				book = service.showBookingDetails(bookid);//Show Booking Details
				System.out.println(book);
			} catch (BookingExceptions e) {
				
				e.printStackTrace();
			}
			break;
			
		case 6:
			System.exit(0);
			break;
			
		} 
		Menu();
		
	}
}
